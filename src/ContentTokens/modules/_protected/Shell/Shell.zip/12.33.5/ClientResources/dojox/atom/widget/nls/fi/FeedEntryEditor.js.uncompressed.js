define(
"dojox/atom/widget/nls/fi/FeedEntryEditor", ({
	doNew: "[uusi]",
	edit: "[muokkaa]",
	save: "[tallenna]",
	cancel: "[peruuta]"
})
);
