//>>built
define("dojox/atom/widget/nls/ar/PeopleEditor",({add:"اضافة",addAuthor:"اضافة مؤلف",addContributor:"اضافة مشارك"}));