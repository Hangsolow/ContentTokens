define("epi-cms/contentediting/command/BlockConvert", [
    "dojo/_base/declare",
    "dojo/when",
    "epi",
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/applicationSettings",
    // Parent class
    "epi-cms/contentediting/command/_ContentAreaCommand",
    "epi-cms/_ContentContextMixin",
    "epi/shell/DialogService",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.editors.contentarea"
], function (
    declare,
    when,
    epi,
    dependency,
    TypeDescriptorManager,
    applicationSettings,
    _ContentAreaCommand,
    _ContentContextMixin,
    dialogService,
    res) {

    return declare([_ContentAreaCommand, _ContentContextMixin], {
        // tags:
        //      internal xproduct

        name: "convert",

        label: res.converttoinlineblock,

        _execute: function () {
            this.contentDataStore = this.contentDataStore || dependency.resolve("epi.storeregistry").get("epi.cms.contentdata");
            when(this.contentDataStore.executeMethod("ConvertSharedBlock", this.model.contentLink)).then(function (result) {
                if (!Object.values(result.data).some(function (x) {
                    return !!x;
                })) {
                    dialogService.alert(res.converttoinlineblockerror);
                    return;
                }

                this.model.parent.modify(function () {
                    this.model.modify(function () {
                        this.model.inlineBlockData = result.data;
                        this.model.contentTypeId = result.contentTypeId;
                        this.model.label = result.name;
                        this.model.name = result.name;
                        // inline blocks have no content link, we need to set it to null
                        this.model.contentLink = null;
                    }.bind(this));
                }.bind(this));
            }.bind(this));
        },

        _getMetadata: function () {
            this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
            return when(this.metadataManager.getMetadataForType("EPiServer.Core.ContentData", { contentLink: this.model.contentLink }),
                function (metadata) {
                    return metadata;
                });
        },

        _onModelValueChange: function () {
            // summary:
            //      Updates canExecute after the model value has changed.
            // tags:
            //      protected

            if (this.model.get("readOnly") || !applicationSettings.inlineBlocksInContentAreaEnabled
                || (applicationSettings.inlineBlocksInContentAreaEnabled
                    // inline blocks are only allowed as part of pages and other blocks for now
                    && !this._currentContext.capabilities.isPage
                    && !this._currentContext.capabilities.isBlock)) {
                this.set("isAvailable", false);
                this.set("canExecute", false);
                return;
            }

            //TODO: Fix support in EPiServer Forms package, for now we disable the command for forms
            var formIdentifier = "episerver.forms.implementation.elements.formcontainerblock";
            if (this.model.typeIdentifier === formIdentifier) {
                this.set("isAvailable", false);
                this.set("canExecute", false);
                return;
            }

            this._typeDescriptorManager = this._typeDescriptorManager || TypeDescriptorManager;
            var isBlockType = this._typeDescriptorManager.isBaseTypeIdentifier(this.model.typeIdentifier, "episerver.core.blockdata");
            var isInlineBlock = this.model && this.model.inlineBlockData;
            this.set("isAvailable", isBlockType && !isInlineBlock);
            this.set("canExecute", isBlockType && !isInlineBlock);
        }
    });
});
