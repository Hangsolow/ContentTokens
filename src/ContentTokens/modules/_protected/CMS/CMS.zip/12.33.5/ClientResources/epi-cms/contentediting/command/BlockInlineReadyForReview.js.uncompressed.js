define("epi-cms/contentediting/command/BlockInlineReadyForReview", [
    "dojo/_base/declare",
    "epi-cms/content-approval/command/ReadyForReview",
    "epi-cms/contentediting/command/_BlockInlineCommandMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/ContentViewModel",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.inlineediting.inlinecommands.inlinereadyforreview"
], function (
    declare,
    ReadyForReview,
    _BlockInlineCommandMixin,
    ContentActionSupport,
    ContentViewModel,
    res
) {

    return declare([ReadyForReview, _BlockInlineCommandMixin], {
        // summary:
        //      Inline command to set the block as ready to review
        // tags:
        //      internal xproduct

        errorMessageHeading: res.error,

        successMessage: res.success,

        executableStatuses: [
            ContentActionSupport.versionStatus.Rejected,
            ContentActionSupport.versionStatus.CheckedOut
        ],

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model has been updated.
            // tags:
            //      protected

            if (!this.model) {
                return;
            }

            if (this._isIgnoredContentType(this.model.typeIdentifier)) {
                this.set("isAvailable", false);
                return;
            }

            var store = this._getEnhancedStore();
            if (!store) {
                return;
            }

            return store.query({ id: this.model.contentLink, keepversion: true }).then(function (latestContent) {
                var contentData = latestContent;

                // Early exit if the current content isn't in the list of the executable statuses
                if (this.executableStatuses.indexOf(contentData.status) === -1) {
                    this._setCommandVisibility(false);
                    return;
                }

                this._setCommandVisibility(true);

                if (this._viewModel) {
                    this._viewModel.destroy();
                }
                this._viewModel = new ContentViewModel({
                    contentLink: contentData.contentLink,
                    contextTypeName: "epi.cms.contentdata"
                });
                this._viewModel.set("contentData", contentData);
                this.model = this._viewModel;
            }.bind(this));
        }
    });
});
